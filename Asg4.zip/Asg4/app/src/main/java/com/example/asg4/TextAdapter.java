package com.example.asg4;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
/**************************************************************************
 * TextAdapter class for the recyclerview
 *
 **************************************************************************/
public class TextAdapter extends RecyclerView.Adapter {
    private List<Player> players = new ArrayList<Player>();
    //set items
    public void setItems(List<Player> players)
    {
        this.players = players;
        notifyDataSetChanged();
    }
    // on createViewHolder method
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if(viewType == 0)
            return(TextViewHolder.inflate(parent));
        else
            return null;
    }
    //bindviewholder
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if(holder instanceof TextViewHolder) {
            ((TextViewHolder)holder).bind(players.get(position));
        }
    }
    // getting the count of the players
    @Override
    public int getItemCount() {
        return players.size();
    }
    public int getItemViewType()
    {
        return 0;
    }

    /**************************************************************************
     * TextViewHolder class
     *
     **************************************************************************/
    static class TextViewHolder extends RecyclerView.ViewHolder {
        private TextView textview;
        TextView tvname, tvscore, tvdate;

        public static TextViewHolder inflate(ViewGroup parent)
        {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_text,parent,false);
            return new TextViewHolder(view);
        }
        public TextViewHolder(@NonNull View itemView) {
            super(itemView);
            //textview = itemView.findViewById(R.id.list);
            tvname = itemView.findViewById(R.id.Name);
            tvscore = itemView.findViewById(R.id.Score);
            tvdate = itemView.findViewById(R.id.Date);

        }

        // Method to bind the values

        public void bind(Player player) {
            tvname.setText(player.getName());
            tvscore.setText(player.getScore());
            tvdate.setText(player.getDate());
        }

    }
}
