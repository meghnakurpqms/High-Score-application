package com.example.asg4;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
/**************************************************************************
 * The class is a filter for setting a range for a numbered EditView
 *
 **************************************************************************/
 class InputFilterMinMax implements InputFilter {
    private int min, max;

    public InputFilterMinMax(int min, int max) {
        this.min = min;
        this.max = max;
    }

    public InputFilterMinMax(String min, String max) {
        this.min = Integer.parseInt(min);
        this.max = Integer.parseInt(max);
    }


    @Override
    public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
        try {
            int input = Integer.parseInt(dest.toString() + source.toString());
            if (isInRange(min, max, input))
                return null;
        } catch (NumberFormatException nfe) { }
        return "";
    }

    private boolean isInRange(int a, int b, int c) {
        return b > a ? c >= a && c <= b : c >= b && c <= a;
    }
}

/**************************************************************************
 * Activity_add class is for the pagewhere user input is added.
 *
 **************************************************************************/
public class Activity_add extends AppCompatActivity {

    EditText editName, highScore;
    TextView datetxt,timetxt;
    Button datebtn,timebtn,btnsave;
    Player player;
    /**************************************************************************
     * Oncreate method for setting all the items on screen
     *
     **************************************************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        editName = (EditText) findViewById(R.id.editName);
        highScore = (EditText) findViewById(R.id.Highscore);
        highScore.setFilters(new InputFilter[]{new InputFilterMinMax("0", "1000000")});
        datetxt = (TextView) findViewById(R.id.datetxt);
        timetxt = (TextView) findViewById(R.id.timetxt);

        datetxt.setText(new SimpleDateFormat("MM-dd-yyyy", Locale.US).format(new Date()));
        timetxt.setText(new SimpleDateFormat("HH:mm",Locale.US).format(new Date()));

        datebtn = (Button)findViewById(R.id.datebtn);
        timebtn = (Button) findViewById(R.id.timebtn);
        btnsave = (Button) findViewById(R.id.btnsave);

        //public boolean set

        editName.setError(null);
        highScore.setError(null);
    }

    /**************************************************************************
     * onClick method
     * Perform the functions for each button
     *
     **************************************************************************/

    public void onClick(View v)
    {
        // if view is the button for date
        if(v == datebtn)
        {
            //Get current year, month, day
            final Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            final int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
            //When button is clicked show date time picker
            DatePickerDialog datePickerDialog = new DatePickerDialog(Activity_add.this,
                    new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                          showDate(year,month+1,day);
                        }
                    },year,month, dayOfMonth);
            //set the max range to current date. Don't let the date time picker to a date beyond today
            datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
            datePickerDialog.show();
            //datebtn.setText("Hello");
        }
        // if view is the time button
        if(v == timebtn)
        {
            //Set current Hour and Minute
            final Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR);
            int min = calendar.get(Calendar.MINUTE);
            //When the button is clicked open the Time Picker
            TimePickerDialog td = new TimePickerDialog(Activity_add.this,
                    new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                            showTime(hourOfDay,minute);
                        }
                    },
                    hour, min,
                    DateFormat.is24HourFormat(Activity_add.this)// set in 24 hour format
            );

            td.show();
        }
        //if view is the save button
        if(v == btnsave)
        {
            // check if every field is valid by calling the valid method
            if (valid()) {
                //Set the intent
                Intent i = new Intent(Activity_add.this, MainActivity.class);
                String name, scoreInformal, score, date, time;
                // get values
                name = editName.getText().toString();
                score = highScore.getText().toString();
                date = datetxt.getText().toString();
                time = timetxt.getText().toString();

                player = new Player(name, score, date, time);

                // for accessing in the MainActivity
                i.putExtra("name", name);
                i.putExtra("score", score);
                i.putExtra("date", date);
                i.putExtra("time", time);

                // set resultcode to RESULT_OK
                setResult(RESULT_OK, i);
                finish();

            } else {

            }
        }//save
        if(v == editName)
        {
            //datebtn.setText("yes");
            editName.setError(null);
        }
        if(v == highScore)
        {
            highScore.setError(null);
        }
    }
    //Show time in the format given below
    private void showTime(int hour,int min)
    {
        timetxt.setText(new StringBuilder().append(hour).append(":").append(min));
    }
    // Show date in the format given below
    private void showDate(int year, int month, int day) {
        datetxt.setText(new StringBuilder().append(month).append("-")
                .append(day).append("-").append(year));
    }

    // Valid method
    private boolean valid() {
        boolean validName, validScore, validDate, validTime;

        //validate name
        if (validNames()) {
            validName = true;
        } else {
            validName = false;
        }

        //validate score
        if (validScores()) {
            validScore = true;
        } else {
            validScore = false;
        }

        //validate date
        if (validDates()) {
            validDate = true;
        } else {
            validDate = false;
        }
        // if all three fields are valid return true
        if (validName && validScore && validDate) {
            return true;
        }

        return false;
    }
    /**************************************************************************
     * Method to check validity of name field
     *if empty give error
     * if value size is more than 30 then give error
     **************************************************************************/
    private boolean validNames() {
        if (editName.getText().toString().trim().isEmpty()) {
            editName.setError("Name cannot be empty");
            return false;
        } else if (editName.getText().toString().trim().length() > 30) {
            editName.setError("Name must be between 1-30 characters");
            return false;
        }
        return true;
    }
    /**************************************************************************
     * Method to check validity of the score field
     *
     **************************************************************************/
    private boolean validScores() {
        int score;
        try {
            if (!highScore.getText().toString().trim().isEmpty()) // ||
            {
                String sc = highScore.getText().toString().trim();
                sc.replaceFirst("^0+(?!$)", "");

                if (sc.length() <= 10) {
                    score = Integer.parseInt(sc);
                    // checking for positive integer even though the range is set
                    if (score <= 0) {
                        highScore.setError("Score must be a positive integer");
                        return false;

                    } else {
                        if (score > 0)
                            return true;
                    }

                } else {
                    highScore.setError("Very Big Score!");
                    return false;
                }
            }

            if (highScore.getText().toString().trim().isEmpty()) // ||
            {
                highScore.setError("Score cannot be empty!");
                return false;
            }
        } catch (NumberFormatException e) {
            {
            }
        }
        return true;
    }
    /**************************************************************************
     * Check the validity of the date selected even though the range is set.
     *
     **************************************************************************/
    private boolean validDates() {
        String date;
        date = datetxt.getText().toString();

        if (date.length() >= 6 && date.length() <= 10) {
            return true;
        } else {
            datetxt.setError("Invalid date format");
            return false;
        }
    }

}
