package com.example.asg4;

import android.content.Context;
import android.os.Environment;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

/**************************************************************************
 * FileIO class for file reading and file writing
 *
 **************************************************************************/
public class FileIO extends AppCompatActivity implements
        View.OnClickListener{
    private static ArrayList<String> list = new ArrayList<String>();
    private static ArrayList<Player> player = new ArrayList<Player>();
    private static String[] playerDetails;
    private static Player play;
    private static String line;

    /**************************************************************************
     * Method for reading a file
     *
     **************************************************************************/
    public static ArrayList<Player> readFile(Context Applicationcontext) {

        try {
                //If line is not empty then don't read from the file otherwise there will be duplicates.
                if(line=="") {
                FileInputStream fileInputStream = Applicationcontext.openFileInput("getscores.txt");
                InputStreamReader input = new InputStreamReader(fileInputStream);
                BufferedReader bufferedReader = new BufferedReader(input);
                while ((line = bufferedReader.readLine()) != null) {
                    list.add(line);
                    // split on tab
                    playerDetails = line.split("\t");
                    if (player != null) {
                        play = new Player(playerDetails[0], playerDetails[1], playerDetails[2], playerDetails[3]);
                        Log.v("string", playerDetails[0]);
                        player.add(play);
                        input.close();

                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return player;
    }
    /**************************************************************************
     * Method to write to a file
     *
     **************************************************************************/
    public static void WriteFile(Context context, ArrayList<Player> playerArrayList) {
        try {

            FileOutputStream fileOut = context.openFileOutput("getscores.txt", MODE_PRIVATE);
            OutputStreamWriter outputWriter = new OutputStreamWriter(fileOut);
            //Write all the values of the arraylist
            for (int i = 0; i < playerArrayList.size(); i++) {
                outputWriter.write(playerArrayList.get(i).getName() + "\t" + playerArrayList.get(i).getScore() + "\t" + playerArrayList.get(i).getDate() + "\t" + playerArrayList.get(i).getTime() + "\n");
                Log.v("string:",playerArrayList.get(i).getName() + "\t" + playerArrayList.get(i).getScore() + "\t" + playerArrayList.get(i).getDate() + "\t" + playerArrayList.get(i).getTime() + "\n");
            }
            outputWriter.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public ArrayList<String> getList() {
        return list;
    }


    @Override
    public void onClick(View view) {

    }
}


