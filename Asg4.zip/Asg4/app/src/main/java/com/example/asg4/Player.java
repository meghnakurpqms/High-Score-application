package com.example.asg4;

import java.io.Serializable;
import java.util.Comparator;
/**************************************************************************
 * Class that has the values for a player. Can be used as a user defined type
 *
 **************************************************************************/
public class Player implements Serializable {
    private String name, score, date, time;

    // constructor
    public Player(String pname, String pscore, String pdate, String ptime)
    {
        name = pname;
        score = pscore;
        date = pdate;
        time = ptime;
    }
    //Get value functions
    public String getName() {
        return name;
    }

    public String getScore() {
        return score;
    }

    public String getDate() { return date; }

    public String getTime() {
        return time;
    }

    // Comparator  for comparing the scores
    public static Comparator<Player> PlayerByScore = new Comparator<Player>() {
        @Override
        public int compare(Player p1, Player p2) {
            int score_1 = Integer.parseInt(p1.getScore());
            int score_2 = Integer.parseInt(p2.getScore());
            return score_2 - score_1; //returning score
        }
    };
    //Comparator  for comparing the dates

    public static Comparator<Player> PlayerByDate = new Comparator<Player>() {
        @Override
        public int compare(Player p1, Player p2) {
            String date_1 = p1.getDate();
            String date_2 = p2.getDate();

            String dateSplit_1 [] = date_1.split("-");
            String dateSplit_2 [] = date_2.split("-");

            int day_1 = Integer.parseInt(dateSplit_1[1]);
            int day_2 = Integer.parseInt(dateSplit_2[1]);

            int month_1 = Integer.parseInt(dateSplit_1[0]);
            int month_2 = Integer.parseInt(dateSplit_2[0]);

            int year_1 = Integer.parseInt(dateSplit_1[2]);
            int year_2 = Integer.parseInt(dateSplit_2[2]);

            if(year_2!=year_1)
            {
                return year_2 - year_1;

            }

            else
            {
                if(month_1!=month_2)
                {
                    return month_2 - month_1;
                }

                else
                    return day_2 - day_1;
            }
        }
    };
    // Comparator for comparing the time
    public static Comparator<Player> PlayerByTime = new Comparator<Player>() {
        @Override
        public int compare(Player p1, Player p2) {
            String time_1 = p1.getTime();
            String time_2 = p2.getTime();

            String timeSplit_1 [] = time_1.split(":");
            String timeSplit_2 [] = time_2.split(":");

            int hour_1 = Integer.parseInt(timeSplit_1[0]);
            int hour_2 = Integer.parseInt(timeSplit_2[0]);

            int minute_1 = Integer.parseInt(timeSplit_1[1]);
            int minute_2 = Integer.parseInt(timeSplit_2[1]);


            if(hour_1 != hour_2)
            {
                return hour_2 - hour_1;
            }

            else
            {
                return minute_2 - minute_1;
            }
        }
    };

}
