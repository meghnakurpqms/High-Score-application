package com.example.asg4;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AbsListView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
/**************************************************************************
 * MainActivity class
 *
 **************************************************************************/
public class MainActivity extends AppCompatActivity {

    // TAG was used for testing
    private static final String TAG = "MyActivity";
    // Global variables
    ArrayList<Player> playinitial;
    ArrayList<Player> playerList;
    ListView listview;
    TextView addbut;
    TextAdapter textAdapter;


    /**************************************************************************
     * onCreate to initialize all buttons, toolbars
     *
     **************************************************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        //Make toolbar action bar
        setSupportActionBar(toolbar);
        // if list is null then write to the file otherwise on leaving the app the values get rewritten on re-entering the app
        if(playinitial == null) {
            // for testing and checking the log
            Log.v(TAG,"here");
            // Read data into playinitial
            playinitial = FileIO.readFile(getApplicationContext());
            // Set your recycler view to view the list
            RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycle_view);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            //if (playinitial != null)
                //Log.v(TAG, playinitial.get(0).getName());


            textAdapter = new TextAdapter();
            //Set the text adapter for recyclerview
            recyclerView.setAdapter(textAdapter);
            textAdapter.setItems(playinitial);
        }
    }

    /**************************************************************************
     * onCreateOptionsMenu method to set your buttons and and lists
     * Call the opensavepage method for opening the save page
     **************************************************************************/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        playerList = new ArrayList<Player>();
        addbut = (TextView)findViewById(R.id.Addbtn);

        addbut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSavepage();
            }
        });

        return true;
    }

    /**************************************************************************
     * openSavepage method to create an Intent
     * Use startActivityForResult
     **************************************************************************/

    public void openSavepage()
    {
        Intent a = new Intent(MainActivity.this, Activity_add.class);
        startActivityForResult(a, 1);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        return super.onOptionsItemSelected(item);
    }
    /**************************************************************************
     * onActivityResult method to get the requestcode and result code and intent
     * if the codes match,
     * Add to the list and sort
     *
     **************************************************************************/
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        Log.v(TAG,"requestcode: " + requestCode);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            //Get the values and store it in variables
            String add_name = data.getStringExtra("name");
            String add_score = data.getStringExtra("score");
            String add_date = data.getStringExtra("date");
            String add_time = data.getStringExtra("time");
            Log.v(TAG, "name=\n" + add_name);
            Player player = new Player(add_name, add_score, add_date, add_time);
            // add to the lists
            playerList.add(player);
            playinitial.add(player);
            // sort
            Collections.sort(playinitial, Player.PlayerByTime);
            Collections.sort(playinitial, Player.PlayerByDate);
            Collections.sort(playinitial, Player.PlayerByScore);
            //set values to the list
            textAdapter.setItems(playinitial);
            textAdapter.notifyDataSetChanged();
            // give a message of success
            Toast.makeText(MainActivity.this, "Score is added successfully!",
                    Toast.LENGTH_SHORT).show();
            // write to the file
            FileIO.WriteFile(getApplicationContext(), playinitial);
        }
    }
}

